﻿namespace Classifier;

public class Sample
{
    public string[] Features { get; set; }
    public string Label { get; set; }
}
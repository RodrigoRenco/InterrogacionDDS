﻿namespace Classifier;

public class ClassificationResult
{
    public double? Score;
    public string? ErrorMessage;
}